package com.raul.huchatiempo;
import android.app.*; import android.os.*; import android.content.*; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 SharedPreferences p; int minutes; TextView balance; int[] amounts={1,5,15,30,60};
 public void onCreate(Bundle b){super.onCreate(b);p=getSharedPreferences("hucha",0);minutes=p.getInt("minutes",0); LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(28,28,28,28);
 TextView t=new TextView(this);t.setText("🏦 Hucha de Tiempo");t.setTextSize(28);t.setGravity(17);r.addView(t,new LinearLayout.LayoutParams(-1,80));
 balance=new TextView(this);balance.setTextSize(42);balance.setGravity(17);r.addView(balance,new LinearLayout.LayoutParams(-1,130));update();
 TextView i=new TextView(this);i.setText("Saldo disponible");i.setGravity(17);r.addView(i,new LinearLayout.LayoutParams(-1,50));
 addLabel(r,"AÑADIR"); LinearLayout a=new LinearLayout(this); for(int n:amounts)a.addView(btn("+"+lab(n),n));r.addView(a);
 addLabel(r,"GASTAR"); LinearLayout g=new LinearLayout(this);for(int n:amounts)g.addView(btn("−"+lab(n),-n));r.addView(g);
 Button set=new Button(this);set.setText("Establecer saldo manualmente");set.setOnClickListener(v->dialog());r.addView(set);setContentView(r); }
 void addLabel(LinearLayout r,String s){TextView x=new TextView(this);x.setText(s);x.setTextSize(18);x.setPadding(0,30,0,10);r.addView(x);}
 Button btn(String s,int d){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->change(d));b.setLayoutParams(new LinearLayout.LayoutParams(0,65,1));return b;}
 void change(int d){minutes=Math.max(0,minutes+d);p.edit().putInt("minutes",minutes).apply();update();}
 void update(){int h=minutes/60,m=minutes%60;balance.setText(h>0?h+" h "+String.format("%02d",m)+" min":m+" min");}
 String lab(int n){return n==60?"1h":n+"m";}
 void dialog(){EditText e=new EditText(this);e.setInputType(2);e.setText(""+minutes);new AlertDialog.Builder(this).setTitle("Establecer saldo").setMessage("Minutos totales:").setView(e).setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(d,w)->{try{minutes=Math.max(0,Integer.parseInt(e.getText().toString()));p.edit().putInt("minutes",minutes).apply();update();}catch(Exception ignored){}}).show();}
}
