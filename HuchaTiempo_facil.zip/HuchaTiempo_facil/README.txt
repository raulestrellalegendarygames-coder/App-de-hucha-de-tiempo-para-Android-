HUCHA DE TIEMPO

1. Abre esta carpeta en Android Studio.
2. Espera a que sincronice Gradle.
3. Build > Build APK(s).
4. Pulsa el enlace que aparece para abrir el APK.

La app guarda el saldo en el móvil y no necesita cuenta ni Internet.
